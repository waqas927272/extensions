// Service Account Configuration
const SERVICE_ACCOUNT_CONFIG = {
  client_email: "googlesheet@ai-voice-agent-frontier.iam.gserviceaccount.com",
  private_key: `-----BEGIN PRIVATE KEY-----
MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCww4mp6cB4eKvT
OOlSks1s2/XbTEO2eYbjccUjBQZWHW8ZWdtlwCU1vfI37FOaqRydBk9pMAXQTjMp
9H1C4Tw+5P1hlWuNrBHPVJJL0HuVPGjrNu2X8QYmEW9tyzvU9pDI1uN0QWOQJbhw
bD+WVnIPlAfxl4iNtxsgV0P8qEUEnOb20oHXkHNXXnV4HXXjz5AjVH0Tx3tuH54Q
NuyQ25Da3eWUe07hC32qbKN4/Kn3gY7irBPMY9P/50IY3U/ryNO+qrBkPCxGz+cy
rtRd7DbOd21CT3i4t1KpQKxlwlr95hVjxso1nIXDUihPQQG/qg8f8VM6mxbBPDKL
FO2elWTtAgMBAAECggEAEDThZJGAutrvgBZ99/rrOEGjlUd1BuA2EJjwBvGxPsiE
lOmy7q2TC84eTOfPU4URUUlQkxea1NoyoTRgHrdpb2fN3npVaeAeouiBYE+dYRWw
le5Lkux/kJJ1KbciRXiU1kEzigdrwj3fHvmhy94hp5F+N/WZiMrCwzCVFG92IoG7
yQt6ws9mwF7xaZZ3Jj6lrFUsX+c9aeMBkLTZZk7GJx052neucOLSB9UKG5J8O+K1
53efyk1rd2Jrrlm4KzlDCRTw/+jiEXKnTnm04vKoYOQoEzCGF6MnCeJ0x84h41If
G0IYZsPlL1aE4qQ/SCQWInmmhsYCTbXx5vfN8itSSQKBgQD37rDoSrNA+KvnEgUm
LGk6K7N+jZHnSVM2HU8V0aKCUTsKhhFT/qEIRmMEH47J6UUCE99x3FSJ81BmDKul
HYqLLY4h/6RYFQlEu2OAEhUqSYauw8UMA/2ZB7hQEPIS6dBr3WOd/FBjxnRqbOte
yOdS4KX9uZri0zegwQhTOyY5uQKBgQC2hADYXnM8lVnPQJODe4yOOjnviOuiuvud
KdvEP/oe9K9qLZErYE0WFqzoKpeanZ/cCLVWlYbbq06A7SD/UyauHxTc1ZBier9/
iRIINWgoHULCYLwRdiO/6eAZAUfM47I0fBm3OiBOM4pYMN7OHc197MHT6jCb5ZJS
E/AgKDlO1QKBgFg/hop4JEuo94781AZdYmsJKQ+PlnJLoCmvzvmGL6DRBwHc7IgI
JwtJ+m56SRnHRP/TUQI3GYQsrd5U/jd8R1b4tRGW68lKW40yYd0xEoWFvEGyfw2i
0f5JSCp/jZp7zOrH13BhYb/R4JgNAs4vFl9ihNLF4MKBydgXPT5a3GVJAoGBAKlK
P05yLQkgrrDiAPGQA4tYzqwzn/zM2t2oGcQqY2GbK6mcom5NYLMATVj7SKuNUN3S
5gBtqSzP9Hz5dgXdpp8TDVLYdJgjqsQs66DZiMbMfUO2XjsEDZzQ3Z/T5DlTadPs
2B1vuM9QVx3+FmuwkQ4gMJjTPEsd4V5oR+5L4PwRAoGAaMYNrmNAEWXuYUVhjT7b
3P+jnPl+xmWzqZP6z41LxXNoORjS9jCM5tGlWjKI5JBVHtNKaUTOjBHFayfgqVUk
JcdgpSjepUrh0cywbg9XJCFmpPiLu9RYAlcnvRASFeMmwvYoxL58mDNygSkKrMGS
bu1pyvzXOu3kO6r4kcBLapo=
-----END PRIVATE KEY-----`,
  project_id: "ai-voice-agent-frontier"
};

class ServiceAccountAuth {
  constructor() {
    this.accessToken = null;
    this.tokenExpiry = null;
  }

  async getAccessToken() {
    // Check if we have a valid cached token
    if (this.accessToken && this.tokenExpiry && Date.now() < this.tokenExpiry) {
      return this.accessToken;
    }

    // Generate new JWT and get access token
    const jwt = await this.createJWT();
    const token = await this.exchangeJWTForToken(jwt);
    
    this.accessToken = token.access_token;
    this.tokenExpiry = Date.now() + (token.expires_in * 1000) - 60000; // Subtract 1 minute for safety
    
    return this.accessToken;
  }

  async createJWT() {
    const header = {
      alg: 'RS256',
      typ: 'JWT'
    };

    const now = Math.floor(Date.now() / 1000);
    const payload = {
      iss: SERVICE_ACCOUNT_CONFIG.client_email,
      scope: 'https://www.googleapis.com/auth/spreadsheets',
      aud: 'https://oauth2.googleapis.com/token',
      exp: now + 3600,
      iat: now
    };

    const encodedHeader = this.base64UrlEncode(JSON.stringify(header));
    const encodedPayload = this.base64UrlEncode(JSON.stringify(payload));
    const unsignedToken = `${encodedHeader}.${encodedPayload}`;

    const signature = await this.signWithPrivateKey(unsignedToken, SERVICE_ACCOUNT_CONFIG.private_key);
    const encodedSignature = this.base64UrlEncode(signature);

    return `${unsignedToken}.${encodedSignature}`;
  }

  async signWithPrivateKey(data, privateKey) {
    // Import the private key
    const keyData = this.pemToArrayBuffer(privateKey);
    const cryptoKey = await crypto.subtle.importKey(
      'pkcs8',
      keyData,
      {
        name: 'RSASSA-PKCS1-v1_5',
        hash: 'SHA-256'
      },
      false,
      ['sign']
    );

    // Sign the data
    const encoder = new TextEncoder();
    const signature = await crypto.subtle.sign(
      'RSASSA-PKCS1-v1_5',
      cryptoKey,
      encoder.encode(data)
    );

    return new Uint8Array(signature);
  }

  pemToArrayBuffer(pem) {
    const b64Lines = pem.replace(/-----[^-]+-----/g, '').replace(/\s/g, '');
    const byteString = atob(b64Lines);
    const byteArray = new Uint8Array(byteString.length);
    
    for (let i = 0; i < byteString.length; i++) {
      byteArray[i] = byteString.charCodeAt(i);
    }
    
    return byteArray.buffer;
  }

  base64UrlEncode(data) {
    if (typeof data === 'string') {
      data = new TextEncoder().encode(data);
    }
    
    const base64 = btoa(String.fromCharCode(...new Uint8Array(data)));
    return base64.replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
  }

  async exchangeJWTForToken(jwt) {
    const response = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: new URLSearchParams({
        grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer',
        assertion: jwt
      })
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Token exchange failed: ${error}`);
    }

    return await response.json();
  }
}

// Export for use in other files
window.ServiceAccountAuth = ServiceAccountAuth;